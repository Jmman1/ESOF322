import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        DB database = new DB();
        while(true){
            System.out.println("Please Enter an option: (Integer 1-4)");
            System.out.println("1. Relational");
            System.out.println("2. NoSQL");
            System.out.println("3. Graph");
            System.out.println("4. Exit");
            Scanner input = new Scanner(System.in);
            int number = input.nextInt();

            if(number == 4){
                break;
            }else{
                DB specificDB = database.setStoreStrategy(number);
                String store = specificDB.Store();
                System.out.println(store);
            }
        }
    }
}