public class Graph extends DB {
    @Override
    public String Store()
    {
        return (super.Store()+ " Using the Graph database");
    }
}
