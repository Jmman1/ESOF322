public class Relational extends DB{

    @Override
    public String Store()
    {
        return (super.Store()+ " Using the relational database");
    }
}
