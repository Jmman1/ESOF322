public class DB {
    public DB(){
    }

    public String Store(){
        return "Data was added.";
    }

    public DB setStoreStrategy(int storeStrategy){
        if(storeStrategy == 1){
            return new Relational();
        }else if(storeStrategy == 2){
            return new NoSQL();
        }else{
            return new Graph();
        }
    }
}
