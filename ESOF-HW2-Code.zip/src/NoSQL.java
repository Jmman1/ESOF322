public class NoSQL extends DB {
    @Override
    public String Store()
    {
        return (super.Store()+ " Using the NoSQL database");
    }
}
